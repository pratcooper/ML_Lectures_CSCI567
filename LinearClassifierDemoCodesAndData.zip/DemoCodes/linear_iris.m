% Demo code for CSCI567: Linear Classifiers on Iris Dataset
clear all;

% 
doPerceptron = 0;
if doPerceptron == 1
    negativeOne = -1;
else
    negativeOne = 0;
    eta = 0.1;
end

% Get Data
traindata = dlmread('iris.data.train');
testdata = dlmread('iris.data.test');
trainlabel = traindata(:, end);
traindata = traindata(:,1:end-1);
testlabel = testdata(:, end);
testdata = testdata(:,1:end-1);

% Change the problem from 3 categories to binary
trainlabel(trainlabel==0) = 1;
testlabel(testlabel==0) = 1;
trainlabel(trainlabel==2) = negativeOne;
testlabel(testlabel==2) = negativeOne;

% Use two features instead of the original 4
traindata = traindata(:, [1 3]);
testdata = testdata(:,[1 3]);
Ntrain = size(traindata,1);
Ntest = size(testdata,1);
% show data
figure(1);
clf;
scatter(traindata(:,1), traindata(:,2), 80, trainlabel, 'filled');
title('Training data');
set(gca,'FontSize', 18);

% adding constant 1
traindata = [ones(Ntrain,1) traindata];
testdata  =[ones(Ntest,1) testdata];
D = size(traindata,2);  % dimensionality
% 
W = zeros(D,1);  % initial W
predTrain = sign(traindata*W);
predTest = sign(testdata*W);
errTrain = length(find(predTrain ~= trainlabel))/Ntrain;
errTest = length(find(predTest ~= testlabel))/Ntest;
fprintf('Iter 0: errTrain: %.2f%%, errTest: %.2f%%\n', 100*errTrain, 100*errTest);

tempx = [4 8];  % temp data for drawing classifier

% outer loop
for iter=1: 200
    % choose a data point
    for n = 1:Ntrain
        if doPerceptron == 1  %perceptron update
            
            if sign(traindata(n,:)*W) ~= trainlabel(n)
                % update W
                W = W + trainlabel(n)*traindata(n,:)';
            end
        else  %logistic regression
            pred_prob = 1/ (1+ exp(-W'*traindata(n,:)'));
            W = W - eta * (pred_prob - trainlabel(n))*traindata(n,:)';
        end
    end
    predTrain = sign(traindata*W); % report errors
    predTest = sign(testdata*W);
    if doPerceptron ==0
        predTrain = (predTrain+1)/2;
        predTest = (predTest+1)/2;
    end
    errTrain = length(find(predTrain ~= trainlabel))/Ntrain;
    errTest = length(find(predTest ~= testlabel))/Ntest;
    fprintf('Iter %d: errTrain: %.2f%%, errTest: %.2f%%\n', iter,100*errTrain, 100*errTest);
    if rem(iter, 20) == 0
        figure(2)
        clf;
        scatter(traindata(:,2), traindata(:,3), 80, trainlabel, 'filled');
        hold on;
        plot(tempx, -(W(1)+W(2)*tempx)/W(3), 'r')
        title('Classifier');
        legend(sprintf('Iter=%d', iter))
        set(gca,'FontSize', 18);

        pause
    end
end

