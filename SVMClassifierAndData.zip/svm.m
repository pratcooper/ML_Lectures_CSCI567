% Demo code for CSCI567: Linear Classifiers on Iris Dataset
clear all;

% 
doPerceptron = 1;
if doPerceptron == 1
    negativeOne = -1;
else
    negativeOne = 0;
    eta = 0.1;
end

% Get Data
traindata = dlmread('iris.data.train');
testdata = dlmread('iris.data.test');
trainlabel = traindata(:, end);
traindata = traindata(:,1:end-1);
testlabel = testdata(:, end);
testdata = testdata(:,1:end-1);

% Change the problem from 3 categories to binary
trainlabel(trainlabel==0) = 1;
testlabel(testlabel==0) = 1;
trainlabel(trainlabel==2) = negativeOne;
testlabel(testlabel==2) = negativeOne;

% Use two features instead of the original 4
traindata = traindata(:, [1 3]);
testdata = testdata(:,[1 3]);
Ntrain = size(traindata,1);
Ntest = size(testdata,1);
% show data
figure(1);
clf;
scatter(traindata(:,1), traindata(:,2), 80, trainlabel, 'filled');
title('Training data');
set(gca,'FontSize', 18);

% adding constant 1
traindata = [ones(Ntrain,1) traindata];
testdata  =[ones(Ntest,1) testdata];
D = size(traindata,2);  % dimensionality


% FORMULAT SVM Quadratic Programming
% Kernel matrix on traindata
gramMatrix = traindata*traindata';
norm2Vector = diag(gramMatrix);
distMatrix = repmat(norm2Vector, 1, Ntrain)+repmat(norm2Vector',Ntrain,1)- 2* gramMatrix;
%kernelSigma = median(sqrt(norm2Vector));
kernelSigma = 10;
K = exp(-distMatrix/kernelSigma/kernelSigma);
Y = trainlabel *trainlabel';


C = 1000; % regularizer
H = K .* Y; % this is the quadratic term in SVM
f = - ones(Ntrain,1);
A = [];
b = [];
Aeq=[];
beq=[];
LB  = zeros(Ntrain,1);
UB = C*ones(Ntrain,1);


a = quadprog(H, f, A, b, Aeq, beq, LB, UB);

% computing training accuracy
predTrain = sign(K*(a .* trainlabel));
fprintf('Train error is %.2f%%\n', length(find(predTrain~=trainlabel))/Ntrain*100);

% test accuracy, computing kernel from test data to train data first
norm2VectorTest = sum(testdata.^2,2);
distMatrixTest = repmat(norm2VectorTest, 1, Ntrain) + repmat(norm2Vector', Ntest,1)- 2* testdata*traindata';
KTest = exp(-distMatrixTest/kernelSigma/kernelSigma);

predTest = sign(KTest*(a .* trainlabel));
fprintf('Test error is %.2f%%\n', length(find(predTest~=testlabel))/Ntest*100);

%
figure(2);
clf;
scatter(traindata(:,2), traindata(:,3), 80, a, 'filled');
title('Support Vectors in the Training data');
set(gca,'FontSize', 18);
colormap(cool)
colorbar


figure(3);
clf;
plot(sort(a), 'LineWidth', 2)
title('Sorted value of a');
set(gca,'FontSize', 18);
